<?php
//include the DB constants
include 'databaseConfig.php';

//hides any unwanted warnings or erros
error_reporting(E_ERROR | E_PARSE);

//conncet to DB
$db = new mysqli($hostName, $hostUser, $hostPass, $dbName);

//if connection fails, indicate DB is down
if($db->connect_errno){
	echo "database down";
}else{	
		//Otherwise attempt to select from the Category table
		$query = "SELECT * FROM category";
		$result = $db->query($query);
		
		//adapted from www.camposha.info/android/php-mysql-listview/
		while($row = mysqli_fetch_array($result)){
			$flag[] = $row;
		}
		//if it worked, print the JSON to be read by the app
		if($flag){
			echo(json_encode($flag));
		}else{
			echo "[]";
	}
	$db->close();
}
?>