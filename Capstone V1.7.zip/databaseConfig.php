<?php
//This is included in every file, sets up the variables
//with the information to connect to the database
 $hostName = "budgethelperdb.cxhmghpewoq4.us-west-2.rds.amazonaws.com";
 $hostUser = "scrublord";
 $hostPass = "Janper12!";
 $dbName = "budgetHelperDB";
 ?>