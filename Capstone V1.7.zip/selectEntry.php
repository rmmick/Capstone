<?php
//include the DB constants
include 'databaseConfig.php';

//hides any unwanted warnings or erros
error_reporting(E_ERROR | E_PARSE);

//conncet to DB
$db = new mysqli($hostName, $hostUser, $hostPass, $dbName);

//if connection fails, indicate DB is down
if($db->connect_errno){
	echo "database down";
}else{
	//Otherwise attempt to select from the entry table
	$username = $_POST['username'];
	$year = $_POST['year'];
	$month = $_POST['month'];
	$category = $_POST['category'];
	//adjust the month to format the SQL properly
	if($month < 10){
		$month = '0' . "$month";
	}
	if($username){
		//check to see which values were given and change the command accordingly
		if($category&&$year&&$month){
			$query = "select * from entry where user_username = '".$username."' and dateEntered like '".$year."-".$month."%' and category_Name = '$category'";
		}
		else if($year&&$month){
			$query = "select * from entry where user_username = '".$username."' and dateEntered like '".$year."-".$month."%'";
		}else{
			$query = "select * from entry where user_username = '".$username."'";
		}
		$result = $db->query($query);
		//adapted from www.camposha.info/android/php-mysql-listview/
		while($row = mysqli_fetch_array($result)){
			$flag[] = $row;
		}
		//if it worked, print the JSON to be read by the app
		if($flag){
			echo (json_encode($flag));
		}
		else{
			echo "[]";
		}
	}
	else{
		echo "Not all required values given";
	}
	$db->close();
}
?>

