<?php
//include the DB constants
include 'databaseConfig.php';

//hides any unwanted warnings or erros
error_reporting(E_ERROR | E_PARSE);

//conncet to DB
$db = new mysqli($hostName, $hostUser, $hostPass, $dbName);

//if connection fails, indicate DB is down
if($db->connect_errno){
	echo "database down";
}else{
	//Otherwise attempt to delete from the user table
	$username = $_POST['username'];
	if($username){
		$query = "DELETE FROM user WHERE username = '" . $username . "'";
		$result = $db->query($query);
		//if it works, return success, otherwise errors
		if($result){
			echo "Data Deleted Successfully";
		}else{
			echo "Error Deleting Data";
		}
	}else{
		echo "Not all required values given";
	}
	//finally close the connection
	$db->close();
}
?>