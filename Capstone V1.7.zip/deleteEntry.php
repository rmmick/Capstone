<?php
//include the DB constants
include 'databaseConfig.php';

//hides any unwanted warnings or erros
error_reporting(E_ERROR | E_PARSE);

//conncet to DB
$db = new mysqli($hostName, $hostUser, $hostPass, $dbName);

//if connection fails, indicate DB is down
if($db->connect_errno){
	echo "database down";
}else{
	//Otherwise attempt to delete from the Entry table
	$username = $_POST['username'];
	$category = $_POST['category'];
	$year = $_POST['year'];
	$month = $_POST['month'];
	$day = $_POST['day'];
	$description =$_POST['description'];
	$amount = $_POST['amount'];
	$place = $_POST['place'];
	if($username&&$category&&$year&&$month&&$day&&$description&&$amount&&$place){
		$query = "delete from entry where user_username = '$username' and dateEntered = '$year-$month-$day' 
		and category_Name = '$category' and description ='$description' and cost = $amount and placeSpent = '$place'";
		$result = $db->query($query);
		//if it works, return success, otherwise errors
		if($result){
			echo "Data Deleted Successfully";
		}
		else{
			echo "Error Deleteing Data";
		}
	}
	else{
		echo "Not all required values given";
	}

	$db->close();
}
?>

