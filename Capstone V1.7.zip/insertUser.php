<?php
//include the DB constants
include 'databaseConfig.php';

//hides any unwanted warnings or erros
error_reporting(E_ERROR | E_PARSE);

//conncet to DB
$db = new mysqli($hostName, $hostUser, $hostPass, $dbName);

//if connection fails, indicate DB is down
if($db->connect_errno){
	echo "database down";
}else{
	//Otherwise attempt to insert into the user table
	$username = $_POST['username'];
	$password = $_POST['password'];
	if($username && $password){
		$query = "insert into user (username, password) values ('$username','$password')";
		$result = $db->query($query);
		//if it worked, indicate that the data was inserted
		if($result){
			echo "Data Inserted Successfully";
		}else{
			echo "Error Inserting Data";
		}
	}else{
		echo "Not all required values given";
	}
	$db->close();
}
?>